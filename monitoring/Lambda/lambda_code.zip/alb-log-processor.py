import json
import boto3
import gzip
import re
import time
from datetime import datetime
from io import BytesIO
from urllib.parse import urlparse

s3 = boto3.client('s3')
logs = boto3.client('logs')

LOG_GROUP_NAME = '/aws/alb/flash-ticket'
LOG_STREAM_NAME = 'alb-access-logs'

def parse_alb_log(line):
    try:
        parts = line.split(None, 2)
        if len(parts) < 3:
            return None

        log_type = parts[0]
        log_time = parts[1]
        rest = parts[2]

        try:
            dt = datetime.fromisoformat(log_time.replace('Z', '+00:00'))
            timestamp_ms = int(dt.timestamp() * 1000)
        except:
            timestamp_ms = int(time.time() * 1000)

        status_code = None
        target_status_code = None
        response_time = None
        request_processing_time = None
        target_processing_time = None
        response_processing_time = None
        service = "unknown"
        request_path = None
        http_method = None

        try:
            fields = line.split()

            if len(fields) > 8:
                try:
                    status_code = int(fields[8])
                except (ValueError, IndexError):
                    pass

            if len(fields) > 9:
                try:
                    target_status_code = int(fields[9])
                except (ValueError, IndexError):
                    pass

            if len(fields) > 7:
                try:
                    request_time = float(fields[5])
                    target_time = float(fields[6])
                    response_time_seconds = float(fields[7])

                    if request_time == -1 or target_time == -1 or response_time_seconds == -1:
                        response_time = None
                    else:
                        response_time = round((request_time + target_time + response_time_seconds) * 1000)
                        request_processing_time = round(request_time * 1000)
                        target_processing_time = round(target_time * 1000)
                        response_processing_time = round(response_time_seconds * 1000)
                except (ValueError, IndexError):
                    pass

            try:
                request_match = re.search(r'"((?:GET|POST|PUT|DELETE|PATCH|HEAD|OPTIONS)\s+[^\s]+\s+HTTP[^"]*)"', line)
                if request_match:
                    request_line = request_match.group(1)

                    parts = request_line.split(None, 2)
                    if len(parts) >= 2:
                        http_method = parts[0]
                        raw_path = parts[1]

                        if raw_path.startswith('http://') or raw_path.startswith('https://'):
                            parsed_url = urlparse(raw_path)
                            request_path = parsed_url.path if parsed_url.path else '/'
                        else:
                            request_path = raw_path.split('?')[0] if '?' in raw_path else raw_path

                        if 'payment' in request_path or 'pay' in request_path:
                            service = "flash-api-payment"
                        elif 'order' in request_path:
                            service = "flash-api-order"
                        elif request_path.startswith('/api/'):
                            if 'payment' in request_path or 'pay' in request_path:
                                service = "flash-api-payment"
                            elif 'order' in request_path:
                                service = "flash-api-order"
                            else:
                                service = "flash-api"
                        elif request_path.startswith('/events'):
                            service = "flash-api"
                        elif request_path.startswith('/queue'):
                            service = "flash-gateway-queue"
                        elif request_path.startswith('/orders'):
                            service = "flash-gateway-orders"
                        elif request_path.startswith('/products'):
                            service = "flash-gateway-products"
                        elif request_path.startswith('/'):
                            service = "flash-gateway"
                        else:
                            service = "unknown"
            except (ValueError, IndexError):
                pass
        except:
            pass

        parsed = {
            'type': log_type,
            'time': log_time,
            'status_code': status_code,
            'target_status_code': target_status_code,
            'response_time_ms': response_time,
            'request_processing_time_ms': request_processing_time,
            'target_processing_time_ms': target_processing_time,
            'response_processing_time_ms': response_processing_time,
            'service': service,
            'request_path': request_path,
            'http_method': http_method,
            'raw_message': line,
            'timestamp_ms': timestamp_ms
        }

        return parsed
    except Exception as e:
        print(f"Error parsing log line: {str(e)}")
        return None

def lambda_handler(event, context):
    try:
        bucket = event['Records'][0]['s3']['bucket']['name']
        key = event['Records'][0]['s3']['object']['key']

        print(f"Processing S3 object: s3://{bucket}/{key}")

        try:
            logs.create_log_stream(
                logGroupName=LOG_GROUP_NAME,
                logStreamName=LOG_STREAM_NAME
            )
        except logs.exceptions.ResourceAlreadyExistsException:
            pass

        response = s3.get_object(Bucket=bucket, Key=key)

        with gzip.GzipFile(fileobj=BytesIO(response['Body'].read())) as gzipfile:
            content = gzipfile.read().decode('utf-8')

        log_events = []
        for line in content.strip().split('
'):
            if not line or line.startswith('#'):
                continue

            parsed = parse_alb_log(line)
            if parsed:
                if parsed['response_time_ms'] is None:
                    continue

                log_events.append({
                    'timestamp': parsed['timestamp_ms'],
                    'message': json.dumps(parsed, ensure_ascii=False)
                })

        if log_events:
            log_events.sort(key=lambda x: x['timestamp'])

            logs.put_log_events(
                logGroupName=LOG_GROUP_NAME,
                logStreamName=LOG_STREAM_NAME,
                logEvents=log_events
            )

            print(f"Successfully uploaded {len(log_events)} log events")

        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Successfully processed ALB logs',
                'bucket': bucket,
                'key': key,
                'events_count': len(log_events)
            })
        }

    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
